# CAREFLOW-X

A Vite + React demonstration prototype for hospital administrative workflow coordination.

## Run locally
```bash
npm install
npm run dev
```

## Production build
```bash
npm run build
npm run preview
```

## Deploy to Vercel
1. Push this project to a GitHub repository.
2. In Vercel, select **Add New → Project** and import the repository.
3. Framework preset: Vite. Build command: `npm run build`. Output directory: `dist`.
4. Deploy.

## Important
This is a front-end demonstration using synthetic sample records and browser-local state. It is not connected to a hospital, EHR, live patient database, or validated machine-learning model. The risk score is a transparent demonstration heuristic. Never enter real patient data. This prototype does not make clinical decisions or authorize discharge.
